(function () {
  const specSelect = document.getElementById('spec-select');
  const themeToggle = document.getElementById('theme-toggle');

  // Paths are relative to this page so the explorer works under any base path.
  const specMap = {
    advanced: {
      label: 'Advanced',
      url: '../specs/gl-advanced.yaml',
    },
    essential: {
      label: 'Essential',
      url: '../specs/gl-essential.yaml',
    },
    baseline: {
      label: 'Baseline',
      url: '../specs/gl-baseline.yaml',
    },
    webhooks: {
      label: 'Webhooks',
      url: '../specs/gl-webhooks.yaml',
    },
  };

  let swaggerInstance;
  let activeTheme = 'light';

  function getSearchParams() {
    return new URLSearchParams(window.location.search);
  }

  function resolveSpecKey() {
    const requested = getSearchParams().get('spec');
    return requested && specMap[requested] ? requested : 'advanced';
  }

  function readStoredTheme() {
    const queryTheme = getSearchParams().get('theme');
    if (queryTheme === 'dark' || queryTheme === 'light') {
      return queryTheme;
    }

    let localTheme = null;
    try {
      localTheme = window.localStorage.getItem('theme') || window.localStorage.getItem('docusaurus.theme');
    } catch (error) {
      localTheme = null;
    }
    if (localTheme === 'dark' || localTheme === 'light') {
      return localTheme;
    }

    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches
      ? 'dark'
      : 'light';
  }

  function applyTheme(theme, persist) {
    activeTheme = theme === 'dark' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', activeTheme);
    document.body.setAttribute('data-theme', activeTheme);
    if (persist) {
      // Only an explicit choice is stored; otherwise the docs keep following the system setting.
      try {
        window.localStorage.setItem('theme', activeTheme);
      } catch (error) {
        // Storage can be unavailable (private mode); the theme still applies for this view.
      }
    }
    const nextThemeLabel = activeTheme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode';
    themeToggle.textContent = nextThemeLabel;
    themeToggle.setAttribute('aria-label', nextThemeLabel);
    themeToggle.setAttribute('aria-pressed', String(activeTheme === 'dark'));
  }

  function setQueryValue(key, value) {
    const params = getSearchParams();
    params.set(key, value);
    const nextUrl = `${window.location.pathname}?${params.toString()}`;
    window.history.replaceState({}, '', nextUrl);
  }

  function renderSwagger(specKey) {
    const spec = specMap[specKey] || specMap.advanced;

    specSelect.value = specKey;
    setQueryValue('spec', specKey);
    document.title = `Global Ledger API Explorer — ${spec.label}`;

    if (swaggerInstance && typeof swaggerInstance.destroy === 'function') {
      swaggerInstance.destroy();
    }

    swaggerInstance = window.SwaggerUIBundle({
      url: spec.url,
      dom_id: '#swagger-ui',
      deepLinking: true,
      docExpansion: 'list',
      defaultModelsExpandDepth: 1,
      displayRequestDuration: false,
      supportedSubmitMethods: [],
      presets: [window.SwaggerUIBundle.presets.apis, window.SwaggerUIStandalonePreset],
      plugins: [window.SwaggerUIBundle.plugins.DownloadUrl],
      layout: 'BaseLayout',
    });
  }

  specSelect.addEventListener('change', function (event) {
    renderSwagger(event.target.value);
  });

  themeToggle.addEventListener('click', function () {
    const nextTheme = activeTheme === 'dark' ? 'light' : 'dark';
    applyTheme(nextTheme, true);
    setQueryValue('theme', nextTheme);
  });

  applyTheme(readStoredTheme(), false);
  renderSwagger(resolveSpecKey());
})();
